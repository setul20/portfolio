Setul Patel

Command:
gcc -Wall -o test main.c
