Setul Patel

I didnt really use a command to compile because i used the makefile.

Thank You! :)
