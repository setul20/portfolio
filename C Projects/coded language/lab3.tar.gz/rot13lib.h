/*
	Filename: rot13lib.h
	Description: Function definitions for rot13lib.c
*/

void rot13(char * _input);

